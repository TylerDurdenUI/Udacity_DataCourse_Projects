Problem 1
List pop or append method, constant time complexity O(1), space is O(n).

Problem 2
Go through all the folders, thus time complexity is linear O(n). Space complexity is O(nlog(n))

Problem 3
One layer of loop, so time complexity is O(n). Space complexity is O(nlog(n)).

Problem 4
Both the time and space complexity is O(n)

Problem 5
Time is O(1) and space complexity is O(n).

Problem 6
Based on the time complexity of union and intersection in Python, the time complexity here is O(n) and O(n^2) for union and intersection, respectively.
Space is O(n).