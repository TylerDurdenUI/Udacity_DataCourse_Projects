def getFreq(message):
    d = {}
    for i in message:
        d[i] = d.get(i,0)+1
    return d.items()

def buildtree(freq):
    """
    Input: freq is list of tuple, of which 1st element is freq, and 2nd ele is letter
    Output: heap tree, a nested list of tuples
    """
    import heapq

    heap = list()
    for _ in freq:
        heapq.heappush(heap,[_])#each node is a list
    while len(heap)>1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        freqleft,labelleft = left[0]
        freqrigh,labelrigh = right[0]
        merge_node = [(freqleft+freqrigh,labelleft+labelrigh),left,right]
        heapq.heappush(heap,merge_node)
    return heap[0]

 def getCode(tree,d={},cur_code = ''):
    """
    Input: tree to be traversed,d is an initially empty dict and record the code as recursive progress
    Output: a list 0 and 1
    """
    if len(tree)==1: # base condition
        freq,letter = tree[0]
        d[letter] = cur_code
    else:
        value, left, right = tree
        getCode(left,d,cur_code+'0')
        getCode(right,d,cur_code+'1')
    return d
def encoding(message):
    freq = getFreq(message)
    tree = buildtree([i[::-1] for i in freq])
    code = getCode(tree)
    encode =  ''.join([code[letter] for letter in message])
    return encode,tree

def decoding(encode,tree):
    pointer = tree
    message = []
    for ele in encode:
        if ele=='0':
            pointer = pointer[1]
        else:
            pointer = pointer[2]
        # check if it is leaf node
        if len(pointer)==1:
            message.append(pointer[0][1])
            pointer = tree
    return(''.join(message))


# testing case
if __name__=='__main__':
	a,b = encoding('Huffman')
	# a = '010001010110011111'
	# b = [(7, 'uHafmn'),[(3, 'uHa'), [(1, 'u')], [(2, 'Ha'), [(1, 'H')], [(1, 'a')]]],[(4, 'fmn'), [(2, 'f')], [(2, 'mn'), [(1, 'm')], [(1, 'n')]]]]
	message = decoding(decoding(a,b)) 
	print(message) # 'Huffman'
        