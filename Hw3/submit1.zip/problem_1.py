def sqrt(num):
    """
    Input: num
    Output: floor of its square root
    """
    if num in [0,1]:
        return num
    start = 1
    end = num
    while start <= end:
        mid = (start+end)//2
        if mid*mid == num:
            return mid
        elif mid*mid<num:
            start = mid+1
            ans = mid
        else:
            end = mid - 1
    return ans
    

# test, 100 cases
import numpy as np
for i in range(100):
    if np.floor(i**.5)!= sqrt(i):
        print("Fail")
    else:
        print('Pass')